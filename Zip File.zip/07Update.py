import mysql.connector as mycon

con=mycon.connect(host='localhost',user='root',password='P3267D',database='bookstoredb')

curs=con.cursor()
try:
    code=int(input('Enter bookCode: '))
    curs.execute("select * from books where bookcode=%d" %code)
    data=curs.fetchone()
    if data:

        Price=int(input("Enter Price: "))

        curs.execute("update books set Price=%d where bookcode=%d"%(Price,code))
        
        con.commit()
        print('New price updated..')
    else:
        print('Book does not exit...')
    

   
        
except:
    print('Error in updation..')