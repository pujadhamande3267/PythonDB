import mysql.connector as mycon
con=mycon.connect(host='localhost',user='root',password='P3267D',database='bookstoredb')
curs=con.cursor()
try:
    bocode=int(input("Enter Book Code "))
    curs.execute("select * from  books where  bookcode=%d" %bocode)
    data=curs.fetchall()
    if data:
        review=input("Update Your Review ")
        curs.execute("UPDATE books SET   review='%s' WHERE  bookcode=%d"%(review,bocode))
        con.commit()
        print("Reviews Updated successfully ")
    else:
        print("Revies Not Updated ")
except:
    print("BOOkCODE IS NOT VALID ")
con.close()

    


