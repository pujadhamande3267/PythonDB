import mysql.connector as mycon

con=mycon.connect(host='localhost',user='root',password='P3267D',database='bookstoredb')

curs=con.cursor()

curs.execute("select author,publication from books")
data=curs.fetchall()
print(data)


con.close()
