import mysql.connector as mycon

con=mycon.connect(host='localhost',user='root',password='P3267D',database='bookstoredb')

curs=con.cursor()

code=int(input('Enter BookCode: '))
curs.execute("select * from books where bookcode=%d"%code)

rec=curs.fetchone()
#print(rec)

try:
    print('Bookname :%s'%rec[1] )
    print('Category :%s'%rec[2])
    print('Author   :%s'%rec[3])
    print('Publication:%s'%rec[4])
    print('Edition:%s'%rec[5])
    print('Price:%d'%rec[6])
except:
    print('Book Not Found')