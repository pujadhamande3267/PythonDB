import mysql.connector as mycon

con=mycon.connect(host='localhost',user='root',password='P3267D',database='bookstoredb')

curs=con.cursor()
try:
    code=int(input('Enter BookCode: '))
    Booknm=input('Enter Book Name: ')
    Category=input('Enter Category: ')
    author=input('Enter Author name of the Book: ')
    publication=input('Enter Publication of book: ')
    edition=input('Enter edition of this book: ')
    price=int(input('Enter Price of this Book: '))
    review=input('Enter Review ')

    curs.execute("insert into books values(%d,'%s','%s','%s','%s','%s',%d,'%s')"%(code,Booknm,Category,author,publication,edition,price,review))
    con.commit()
    print('Book is Added to DataBase')
except:
    print('Not Added...')
con.close()