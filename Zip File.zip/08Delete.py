import mysql.connector as mycon

con=mycon.connect(host='localhost',user='root',password='P3267D',database='bookstoredb')

curs=con.cursor()
try:
    code=int(input('Enter BookCode: '))

    curs.execute("select * from books where bookcode=%d" %code)
    data=curs.fetchone()
    print(data)

    if data:
        ask=input('Do You Want To Delete ')
        if ask.upper()=='YES':

          curs.execute("delete from books where bookcode=%d" %code)
          con.commit()
          print('Book is deleted successfully')
    else:
        print('Book is not found')
        
except:
    print('Error in updation..')