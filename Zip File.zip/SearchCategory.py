import mysql.connector as mycon

con=mycon.connect(host='localhost',user='root',password='P3267D',database='bookstoredb')

curs=con.cursor()
category=input('Enter Category of Book: ')
curs.execute("select * from books where category='%s'"%category)

data=curs.fetchall()
print(data)

con.close()
